<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Assessment</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <lastRun>2018-09-12T22:00:41</lastRun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>49af9620-c8b5-4481-932d-ae135da8c152</testSuiteGuid>
   <testCaseLink>
      <guid>a36d0dbe-c35b-4a94-8c2e-a94efc27534b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Task 1 - API/Task1_API_01_list_of_all_dog_breeds</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>ff34bb42-ab99-4286-ba38-2c647abd4ad1</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Task 1 - API/Task1_API_02_verify_retriever_breed_is_within_the_list</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>ae42ffc5-6602-4820-9a8d-1eef87728f21</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Task 1 - API/Task1_API_03_sub-breeds_for_retriever</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>c6ecbf91-043c-4b8f-a4f4-a85efa74019f</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Task 1 - API/Task1_API_04_List_random_link_for_the_sub-breed_golden</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
