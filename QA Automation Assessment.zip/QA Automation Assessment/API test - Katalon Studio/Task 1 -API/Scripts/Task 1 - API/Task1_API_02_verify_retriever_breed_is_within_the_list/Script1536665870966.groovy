import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import groovy.json.JsonSlurper as JsonSlurper
import java.awt.Desktop as Desktop
import java.io.File as File
import java.io.IOException as IOException

response = WS.sendRequest(findTestObject('List_of_all_dog_breeds'))

WS.verifyResponseStatusCode(response, 200)

JsonSlurper jsl = new JsonSlurper()

Map parsedResponse = jsl.parseText(response.getResponseText())

println(parsedResponse.message.containsKey('retriever'))

FileWriter fw = new FileWriter('C:\\QA Automation Assessment\\API test - Katalon Studio\\Verify_Retriever_in_List.txt', false)

fw.write('Result contains retriever is ' + parsedResponse.message.containsKey('retriever'))

fw.close()

